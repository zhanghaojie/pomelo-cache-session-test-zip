var cluster = require("cluster");
var pomelo = require("./pomelo-nodejs-driver.js").pomelo;

var workers = 120;

var workerReqPerSec = 50;

var maxReqCount = 100;

if (cluster.isMaster) {
   while(workers > 0) {
      workers--;
      cluster.fork();
   }
   //
   setTimeout(function(){
      for(var id in cluster.workers) {
         var worker = cluster.workers[id];
         worker.send("start");
      }
   }, 5000);
}
else {
   pomelo.init({
      host: "127.0.0.1",
      port: 3010
   }, function() {
      pomelo.request("connector.entryHandler.entry", {bindMore: true}, function(result) {
         console.log(result);
      })
   })
   var worker = cluster.worker;
   worker.on("message", function(msg) {
      if (msg === "start") {
         startRequest();
      }
   })
}


function startRequest() {
   var finished = true;
   var count = 0;
   var maxTime = 0;
   var minTime = 0;
   var averageTime = 0;
   var totalTime  = 0;
   var timerHandler = setInterval(function() {
      var request = function(startTime) {
         pomelo.request("chat.chatHandler.chat", {msg: "hello chat"}, function(result) {
            var time = Date.now() - startTime;
            if (time > maxTime) {maxTime = time}
            if (time < minTime) {minTime = time}
            totalTime = totalTime + time;
            count ++;
            finished = true;
            //console.log(result.msg + "-----" + time);
         })
      }
      if (count > maxReqCount) {
         console.log("max request time: " + maxTime);
         console.log("min request time: " + minTime);
         console.log("request average time: " +  totalTime/count)
         clearInterval(timerHandler);
         return;
      }
      if (finished) {
         request(Date.now())
         finished = false;
      }


   }, 1.0/workerReqPerSec)
}
